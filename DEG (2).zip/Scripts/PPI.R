# Install CRAN packages
cran_packages <- c(
  "STRINGdb",
  "igraph",
  "ggraph",
  "tidygraph",
  "dplyr",
  "tidyr",
  "ggplot2",
  "ggrepel",
  "patchwork"
)

# Restore the standard Bioconductor repositories
options(repos = BiocManager::repositories())

# Install STRINGdb from Bioconductor
BiocManager::install(
  "STRINGdb",
  version = "3.21",
  ask = FALSE,
  update = FALSE
)

to_install <- cran_packages[
  !vapply(cran_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(to_install) > 0) {
  install.packages(to_install)
}

# Install Bioconductor packages if required
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}

if (!requireNamespace("org.Hs.eg.db", quietly = TRUE)) {
  BiocManager::install("org.Hs.eg.db")
}

library(STRINGdb)
library(igraph)
library(ggraph)
library(tidygraph)
library(dplyr)
library(tidyr)
library(ggplot2)
library(ggrepel)
library(org.Hs.eg.db)
library(AnnotationDbi)
library(patchwork)

set.seed(123)

# Output directories
dir.create("Results/PPI", recursive = TRUE, showWarnings = FALSE)
dir.create("Results/Hub_Genes", recursive = TRUE, showWarnings = FALSE)
dir.create("Results/Gene_Pathway_Network",
           recursive = TRUE, showWarnings = FALSE)

dir.create("plot/PPI", recursive = TRUE, showWarnings = FALSE)
dir.create("plot/Hub_Genes", recursive = TRUE, showWarnings = FALSE)
dir.create("plot/Gene_Pathway_Network",
           recursive = TRUE, showWarnings = FALSE)

# Load previous workspace
load(file= "Functional_Enrichment.RData")



# Check required columns
stopifnot(
  all(c("Symbol", "adj.P.Val", "threshold") %in%
        colnames(deg_results))
)

# Select significant upregulated and downregulated genes
sig_degs <- deg_results %>%
  filter(
    !is.na(Symbol),
    !is.na(adj.P.Val),
    adj.P.Val < 0.05,
    threshold %in% c("Upregulated", "Downregulated")
  ) %>%
  distinct(Symbol, .keep_all = TRUE)

ppi_symbols <- unique(sig_degs$Symbol)

cat("Significant DEGs:", length(ppi_symbols), "\n")

# Initialise STRING database for human proteins
string_db <- STRINGdb$new(
  version = "12.0",
  species = 9606,
  score_threshold = 700
)

# Map gene symbols to STRING identifiers
gene_map <- data.frame(
  gene = ppi_symbols,
  stringsAsFactors = FALSE
)

mapped_genes <- string_db$map(
  gene_map,
  "gene",
  removeUnmappedRows = TRUE
)

cat("Genes mapped to STRING:",
    nrow(mapped_genes), "\n")


cat("Mapped genes:", nrow(mapped_genes), "\n")
cat("Missing STRING IDs:", sum(is.na(mapped_genes$STRING_id)), "\n")

head(mapped_genes$STRING_id, 10)

rlang::last_trace()

packageVersion("STRINGdb")
packageVersion("igraph")

methods(class = "STRINGdb")

slotNames(string_db)

string_db$load

string_db$get_subnetwork

string_db@.xData
ls(envir = string_db@.xData)

# Access the environment containing the STRINGdb methods
string_env <- string_db@.xData

# Create a corrected version of the load() method
fixed_load <- function() {
  
  network_type_param <- ""
  
  if (tolower(network_type) == "physical") {
    network_type_param <- "physical."
  }
  
  link_data_param <- "links.v"
  
  if (tolower(link_data) == "detailed") {
    link_data_param <- "links.detailed.v"
  } else if (tolower(link_data) == "full") {
    link_data_param <- "links.full.v"
  }
  
  url <- paste(
    protocol,
    "://stringdb-downloads.org/download/protein.",
    network_type_param,
    link_data_param,
    file_version,
    "/",
    species,
    ".protein.",
    network_type_param,
    link_data_param,
    file_version,
    ".txt.gz",
    sep = ""
  )
  
  temp <- downloadAbsentFile(url, oD = input_directory)
  
  PPI <- read.table(
    temp,
    sep = " ",
    header = TRUE,
    stringsAsFactors = FALSE,
    fill = TRUE
  )
  
  # Confirm that the expected columns are available
  required_cols <- c(
    "protein1",
    "protein2",
    "combined_score"
  )
  
  if (!all(required_cols %in% names(PPI))) {
    stop(
      "Unexpected STRING interaction file columns: ",
      paste(names(PPI), collapse = ", ")
    )
  }
  
  # Retain only the columns needed for the PPI graph
  PPI <- PPI[, required_cols, drop = FALSE]
  
  # Clean incomplete records BEFORE applying score filters
  PPI <- PPI[
    complete.cases(PPI) &
      nzchar(PPI$protein1) &
      nzchar(PPI$protein2),
    ,
    drop = FALSE
  ]
  
  PPI$combined_score <- as.numeric(PPI$combined_score)
  
  PPI <- PPI[
    !is.na(PPI$combined_score) &
      PPI$protein1 != PPI$protein2,
    ,
    drop = FALSE
  ]
  
  # Apply the configured STRING confidence threshold
  if (length(score_threshold) != 0) {
    PPI <- PPI[
      PPI$combined_score >= score_threshold,
      ,
      drop = FALSE
    ]
  }
  
  # Restrict the network to the configured background, if supplied
  if (!is.null(backgroundV)) {
    PPI <- PPI[
      PPI$protein1 %in% backgroundV &
        PPI$protein2 %in% backgroundV,
      ,
      drop = FALSE
    ]
  }
  
  # Build the graph from the cleaned edge table
  myg <- igraph::graph_from_data_frame(
    PPI,
    directed = FALSE
  )
  
  graph <<- myg
  
  return(myg)
}

# Make the corrected function use STRINGdb's existing configuration
environment(fixed_load) <- string_env

# Replace load() for this STRINGdb object
assign("load", fixed_load, envir = string_env)


# Retrieve interactions among mapped proteins
ppi_edges_raw <- string_db$get_interactions(
  unique(mapped_genes$STRING_id)
)

cat("Interaction table dimensions:", dim(ppi_edges_raw), "\n")
head(ppi_edges_raw)
names(ppi_edges_raw)



########
exists("string_db")
exists("mapped_genes")

if (exists("mapped_genes")) {
  head(mapped_genes)
  names(mapped_genes)
}

########
head(deg_results$Symbol, 10)
sum(is.na(deg_results$Symbol))
sum(deg_results$Symbol == "", na.rm = TRUE)


gene_list <- deg_results %>%
  filter(!is.na(Symbol), Symbol != "") %>%
  distinct(Symbol) %>%
  pull(Symbol)

length(gene_list)
head(gene_list)

mapped_genes <- string_db$map(
  data.frame(gene = gene_list),
  "gene",
  removeUnmappedRows = TRUE
)

dim(mapped_genes)
head(mapped_genes)


# Mapping results
cat("Total input genes:", length(gene_list), "\n")
cat("Successfully mapped:", nrow(mapped_genes), "\n")
cat("Unmapped genes:", length(gene_list) - nrow(mapped_genes), "\n")

########


# Convert STRING identifiers back to gene symbols
id_map <- mapped_genes %>%
  distinct(STRING_id, .keep_all = TRUE) %>%
  select(STRING_id, gene)

ppi_edges <- ppi_edges_raw %>%
  transmute(
    from = as.character(from),
    to = as.character(to),
    combined_score = as.numeric(combined_score)
  ) %>%
  filter(
    !is.na(combined_score),
    combined_score >= 700,
    from != to
  ) %>%
  left_join(
    id_map,
    by = c("from" = "STRING_id")
  ) %>%
  rename(gene_from = gene) %>%
  left_join(
    id_map,
    by = c("to" = "STRING_id")
  ) %>%
  rename(gene_to = gene) %>%
  filter(
    !is.na(gene_from),
    !is.na(gene_to),
    gene_from != gene_to
  ) %>%
  transmute(
    from = gene_from,
    to = gene_to,
    combined_score
  ) %>%
  rowwise() %>%
  mutate(
    edge_key = paste(sort(c(from, to)), collapse = "||")
  ) %>%
  ungroup() %>%
  arrange(desc(combined_score)) %>%
  distinct(edge_key, .keep_all = TRUE) %>%
  select(-edge_key)

# Build an undirected PPI graph
ppi_graph <- graph_from_data_frame(
  ppi_edges,
  directed = FALSE
)

# Add gene-expression information to nodes
V(ppi_graph)$logFC <- sig_degs$logFC[
  match(V(ppi_graph)$name, sig_degs$Symbol)
]

V(ppi_graph)$direction <- sig_degs$threshold[
  match(V(ppi_graph)$name, sig_degs$Symbol)
]

# Network summary
ppi_summary <- data.frame(
  Genes_in_network = vcount(ppi_graph),
  Interactions = ecount(ppi_graph),
  Isolates_removed = length(ppi_symbols) -
    vcount(ppi_graph),
  Confidence_threshold = 700
)

print(ppi_summary)

# Export network files
write.csv(
  ppi_edges,
  "Results/PPI/STRING_PPI_Edges.csv",
  row.names = FALSE
)

write.csv(
  as_data_frame(ppi_graph, what = "vertices"),
  "Results/PPI/STRING_PPI_Nodes.csv",
  row.names = FALSE
)

write.csv(
  ppi_summary,
  "Results/PPI/PPI_Network_Summary.csv",
  row.names = FALSE
)

# Visualise the PPI network
ppi_plot <- ggraph(ppi_graph, layout = "fr") +
  geom_edge_link(
    aes(width = combined_score),
    colour = "grey70",
    alpha = 0.45,
    show.legend = FALSE
  ) +
  geom_node_point(
    aes(
      size = degree(ppi_graph)[name],
      colour = direction
    ),
    alpha = 0.9
  ) +
  geom_node_text(
    aes(label = name),
    repel = TRUE,
    size = 2.8,
    max.overlaps = 30
  ) +
  scale_edge_width(range = c(0.2, 1.2)) +
  scale_size_continuous(range = c(2, 7)) +
  labs(
    title = "STRING Protein–Protein Interaction Network",
    subtitle = "Human DEGs; STRING confidence score ≥ 700",
    colour = "Expression",
    size = "Degree",
    x = NULL,
    y = NULL
  ) +
  theme_void(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    legend.position = "right"
  )

print(ppi_plot)
ggsave(
  "plot/PPI/STRING_PPI_Network.tiff",
  ppi_plot,
  device = "tiff",
  width = 12,
  height = 10,
  units = "in",
  dpi = 600,
  compression = "lzw",
  bg = "white"
)




# Ensure that the PPI network contains nodes and edges
stopifnot(
  inherits(ppi_graph, "igraph"),
  vcount(ppi_graph) > 0,
  ecount(ppi_graph) > 0
)

# Calculate centrality metrics
hub_results <- data.frame(
  Gene = V(ppi_graph)$name,
  Degree = degree(ppi_graph),
  Betweenness = betweenness(
    ppi_graph,
    directed = FALSE,
    normalized = TRUE
  ),
  Closeness = harmonic_centrality(
    ppi_graph,
    normalized = TRUE
  ),
  Eigenvector = eigen_centrality(
    ppi_graph,
    directed = FALSE,
    weights = NA
  )$vector
)

# Replace undefined centrality values, if any
hub_results <- hub_results %>%
  mutate(
    across(
      c(Degree, Betweenness, Closeness, Eigenvector),
      ~ replace(.x, !is.finite(.x), 0)
    )
  )

# Rank genes independently using each metric
hub_results <- hub_results %>%
  mutate(
    Rank_Degree = rank(-Degree, ties.method = "average"),
    Rank_Betweenness = rank(
      -Betweenness, ties.method = "average"
    ),
    Rank_Closeness = rank(
      -Closeness, ties.method = "average"
    ),
    Rank_Eigenvector = rank(
      -Eigenvector, ties.method = "average"
    ),
    Mean_Consensus_Rank = rowMeans(
      across(starts_with("Rank_")),
      na.rm = TRUE
    )
  ) %>%
  arrange(Mean_Consensus_Rank)

# Select the top 20 consensus-ranked genes
top_hubs <- hub_results %>%
  slice_head(n = min(20, nrow(hub_results)))

print(top_hubs)

# Export all centrality results and top hubs
write.csv(
  hub_results,
  "Results/Hub_Genes/All_Hub_Centrality_Rankings.csv",
  row.names = FALSE
)

write.csv(
  top_hubs,
  "Results/Hub_Genes/Top20_Consensus_Hub_Genes.csv",
  row.names = FALSE
)

# Visualise the top 20 genes across centrality measures
hub_long <- top_hubs %>%
  select(
    Gene,
    Rank_Degree,
    Rank_Betweenness,
    Rank_Closeness,
    Rank_Eigenvector
  ) %>%
  pivot_longer(
    cols = starts_with("Rank_"),
    names_to = "Metric",
    values_to = "Rank"
  ) %>%
  mutate(
    Metric = recode(
      Metric,
      Rank_Degree = "Degree",
      Rank_Betweenness = "Betweenness",
      Rank_Closeness = "Closeness",
      Rank_Eigenvector = "Eigenvector"
    )
  )

hub_rank_plot <- ggplot(
  hub_long,
  aes(
    x = Rank,
    y = reorder(Gene, -MeanRank),
    colour = Metric
  )
) +
  geom_point(size = 2.8) +
  scale_x_reverse() +
  labs(
    title = "Hub-Gene Ranking Across Centrality Metrics",
    x = "Rank (1 = highest)",
    y = "Gene",
    colour = "Centrality metric"
  ) +
  theme_bw(base_size = 11) +
  theme(
    plot.title = element_text(face = "bold"),
    panel.grid.minor = element_blank()
  )

# Add mean rank for plotting order
hub_long <- hub_long %>%
  left_join(
    top_hubs %>%
      transmute(Gene, MeanRank = Mean_Consensus_Rank),
    by = "Gene"
  )

# Recreate plot after adding MeanRank
hub_rank_plot <- ggplot(
  hub_long,
  aes(
    x = Rank,
    y = reorder(Gene, -MeanRank),
    colour = Metric
  )
) +
  geom_point(size = 2.8) +
  scale_x_reverse() +
  labs(
    title = "Hub-Gene Ranking Across Centrality Metrics",
    x = "Rank (1 = highest)",
    y = "Gene",
    colour = "Centrality metric"
  ) +
  theme_bw(base_size = 11) +
  theme(
    plot.title = element_text(face = "bold"),
    panel.grid.minor = element_blank()
  )

print(hub_rank_plot)

ggsave(
  "plot/Hub_Genes/Hub_Gene_Centrality_Rankings.tiff",
  hub_rank_plot,
  device = "tiff",
  width = 10,
  height = 8,
  units = "in",
  dpi = 600,
  compression = "lzw",
  bg = "white"
)

# Identify network communities using Louvain clustering
louvain_result <- cluster_louvain(
  ppi_graph,
  weights = E(ppi_graph)$combined_score
)

V(ppi_graph)$Module <- membership(louvain_result)[
  V(ppi_graph)$name
]

module_table <- data.frame(
  Gene = V(ppi_graph)$name,
  Module = V(ppi_graph)$Module
)

write.csv(
  module_table,
  "Results/Hub_Genes/Louvain_Network_Modules.csv",
  row.names = FALSE
)

# Visualise network modules
module_plot <- ggraph(ppi_graph, layout = "fr") +
  geom_edge_link(
    colour = "grey75",
    alpha = 0.35
  ) +
  geom_node_point(
    aes(colour = factor(Module), size = degree(ppi_graph))
  ) +
  geom_node_text(
    aes(label = name),
    repel = TRUE,
    size = 2.5,
    max.overlaps = 25
  ) +
  labs(
    title = "PPI Network Modules",
    colour = "Louvain module",
    size = "Degree",
    x = NULL,
    y = NULL
  ) +
  theme_void(base_size = 12) +
  theme(plot.title = element_text(face = "bold"))

print(module_plot)

ggsave(
  "plot/Hub_Genes/PPI_Network_Modules.tiff",
  module_plot,
  device = "tiff",
  width = 12,
  height = 10,
  units = "in",
  dpi = 600,
  compression = "lzw",
  bg = "white"
)








# Use your existing enrichment objects
GO_sig <- as.data.frame(go_ora) %>%
  filter(p.adjust < 0.05)

KEGG_sig <- as.data.frame(kegg_ora) %>%
  filter(p.adjust < 0.05)

# Select the top significant GO and KEGG terms
top_GO_terms <- GO_sig %>%
  arrange(p.adjust) %>%
  slice_head(n = 10) %>%
  mutate(Source = "GO")

top_KEGG_terms <- KEGG_sig %>%
  arrange(p.adjust) %>%
  slice_head(n = 10) %>%
  mutate(Source = "KEGG")

pathway_results <- bind_rows(
  top_GO_terms,
  top_KEGG_terms
)

# Convert Entrez identifiers to gene symbols where necessary
convert_gene_ids <- function(x) {
  
  ids <- unique(unlist(strsplit(
    as.character(x),
    "/",
    fixed = TRUE
  )))
  
  ids <- ids[!is.na(ids) & ids != ""]
  
  # Convert numeric Entrez IDs; preserve existing symbols
  is_entrez <- grepl("^\\d+$", ids)
  
  converted <- ids
  
  if (any(is_entrez)) {
    mapped_symbols <- AnnotationDbi::mapIds(
      org.Hs.eg.db,
      keys = ids[is_entrez],
      column = "SYMBOL",
      keytype = "ENTREZID",
      multiVals = "first"
    )
    
    converted[is_entrez] <- ifelse(
      is.na(mapped_symbols),
      ids[is_entrez],
      unname(mapped_symbols)
    )
  }
  
  unique(converted[!is.na(converted) & converted != ""])
}

# Construct gene–pathway edges
gene_pathway_edges <- pathway_results %>%
  select(Description, Source, geneID) %>%
  mutate(
    genes = lapply(geneID, convert_gene_ids),
    pathway = paste(Source, Description, sep = ": ")
  ) %>%
  select(pathway, genes) %>%
  tidyr::unnest(genes) %>%
  transmute(
    from = genes,
    to = pathway
  ) %>%
  distinct()

# Check whether a network can be constructed
if (nrow(gene_pathway_edges) == 0) {
  stop(
    "No gene-pathway edges found. Check the significant ",
    "enrichment results and geneID columns."
  )
}

# Define node types and labels
gene_nodes <- data.frame(
  name = unique(gene_pathway_edges$from),
  type = "Gene",
  stringsAsFactors = FALSE
)

pathway_nodes <- data.frame(
  name = unique(gene_pathway_edges$to),
  type = "Pathway",
  stringsAsFactors = FALSE
)

network_nodes <- bind_rows(gene_nodes, pathway_nodes) %>%
  distinct(name, .keep_all = TRUE) %>%
  mutate(label = name)

# Construct bipartite graph
gene_pathway_graph <- graph_from_data_frame(
  gene_pathway_edges,
  directed = FALSE,
  vertices = network_nodes
)

# Export network data
write.csv(
  gene_pathway_edges,
  "Results/Gene_Pathway_Network/Gene_Pathway_Edges.csv",
  row.names = FALSE
)

write.csv(
  network_nodes,
  "Results/Gene_Pathway_Network/Gene_Pathway_Nodes.csv",
  row.names = FALSE
)

# Create the visualisation
gene_pathway_plot <- ggraph(
  gene_pathway_graph,
  layout = "fr"
) +
  geom_edge_link(
    colour = "grey75",
    alpha = 0.5
  ) +
  geom_node_point(
    aes(
      colour = type,
      size = ifelse(type == "Gene", 4, 7)
    ),
    alpha = 0.9
  ) +
  geom_node_text(
    aes(label = label),
    repel = TRUE,
    size = 2.7,
    max.overlaps = 40
  ) +
  scale_size_identity() +
  labs(
    title = "Gene–Pathway Association Network",
    subtitle = "Significantly enriched GO terms and KEGG pathways",
    colour = "Node type",
    x = NULL,
    y = NULL
  ) +
  theme_void(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    legend.position = "right"
  )

print(gene_pathway_plot)

ggsave(
  "plot/Gene_Pathway_Network/Gene_Pathway_Network.tiff",
  gene_pathway_plot,
  device = "tiff",
  width = 14,
  height = 12,
  units = "in",
  dpi = 600,
  compression = "lzw",
  bg = "white"
)


save.image(file= "Network_Analysis.RData")
